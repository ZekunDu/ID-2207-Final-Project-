#ifndef EMPLOYEE_H
#define EMPLOYEE_H

#include <string>
#include "request.h"
#include "login.h"
#include "employee_record.h"
#include "service_production.h"
using namespace std;

class employee{   //financial manager
    // this is a general type of employees
protected:
    string name;
    string id;
    string position;
    employee_record *record;
public:
    employee(){
        record = new employee_record;
    }
    employee(string Name, string Id, string Position){
        name = Name;
        id = Id;
        position = Position;
    }
    void add_to_list();
    void add_employee_record(string proj_ref, string roll){
        record->add_employee_record(proj_ref, roll);
    }
    void show_employee_record(){
        cout << "Employee record for " << name << ", " << position << ": " << endl;
        record->show_employee_record();
    }
    void changeName(string Name){
        name = Name;
    }
    void changeID(string ID){
        id = ID;
    }
    void changePosition(string Position){
        position = Position;
    }
    string getName(){
        return name;
    }
    string getPosition(){
        return position;
    }
    string getID(){
        return id;
    }
};

employee * employee_list[login_size];

void add_employee_list(employee * person);
void add_employee_list(employee * person){
    int i = 0;
    while (employee_list[i] != NULL)
        i++;
    if (i >= login_size){
        cout << "Too many people!" << endl;
        return;
    }
    employee_list[i] = person;
}

void employee::add_to_list(){
    add_employee_list(this);
}

class fm : public employee{
public:
    fm(){}
    fm(string Name, string Id, string Position){
        name = Name;
        id = Id;
        position = Position;
    }
    void createFinancialTask(string date, string depart,
                             string projref, long amount, string rsn, string cmt){
        if (!checkLogin(name)){
            cout << name << " has not logged in yet." << endl;
            return;
        }
        ftask *newFTpointer = new ftask(date, depart, projref, amount, rsn);
        newFTpointer->addComments(cmt);
        addFinancialTask(financialTaskList, newFTpointer);
        record->add_employee_record(projref, "Sender"); // add record to profile
        for (int i = 0; i < login_size; i++){
            // add record to task receivers
            if (employee_list[i]->getPosition() == "Accountant"){
                employee_list[i]->add_employee_record(projref, "Receiver");
            }
        }
        return;
    }
    void viewFinancialRequestStatus(){
        //list all request with status
        if (!checkLogin(name)){
            cout << name << " has not logged in yet." << endl;
            return;
        }
        cout << endl << "//Financial manager " << name <<
            " views financial requests statuses." << endl;
        for (int i = 0; i < 10; i++){
            if (financialRequestList[i] == NULL) return;
            else{
                freq *freq_pointer = financialRequestList[i];
                freq_pointer->view();
            }
        }
    }
    void solve(freq *f_request){
        if (!checkLogin(name)){
            cout << name << " has not logged in yet." << endl;
            return;
        }
        f_request->changeStatus();
    }
    void addFeedback(freq *f_request, string feedback){
        if (!checkLogin(name)){
            cout << name << " has not logged in yet." << endl;
            return;
        }
        f_request->addFeedback(feedback);
    }

    /*test record*/
    bool isRecordExist(){
        if (record == NULL)
            return false;
        else return true;
    }

};

class fa : public employee{   //financial accountant
    // this is a general type of employees
public:
    fa(){}
    fa(string Name, string Id, string Position){
        name = Name;
        id = Id;
        position = Position;
    }
    void viewFinancialTask(){
        //list all f-task details
        if (!checkLogin(name)){
            cout << name << " has not logged in yet." << endl;
            return;
        }
        cout << endl << "//Financial accountant " << name <<
            " views financial tasks." << endl;
        for (int i = 0; i < 10; i++){
            if (financialTaskList[i] == NULL) return;
            else{
                ftask *ftask_pointer = financialTaskList[i];
                ftask_pointer->view();
            }
        }
    }

};

class pm : public employee{
    //production manager
public:
    pm();
    pm(string Name, string Id, string Position){
        name = Name;
        id = Id;
        position = Position;
    }
    void createFinancialRequest(string date, string depart,
                           string projref, long amount, string rsn){
        //new a f-request and add it to global list.
        if (!checkLogin(name)){
            cout << name << " has not logged in yet." << endl;
            return;
        }
        freq *newFReqPointer = new freq(date, depart, projref, amount, rsn);
        addFinancialRequest(financialRequestList, newFReqPointer);
        record->add_employee_record(projref, "Sender"); // add record to profile
        for (int i = 0; i < login_size; i++){
            // add record to task receivers
            if (employee_list[i]->getPosition() == "Financial Manager"){
                employee_list[i]->add_employee_record(projref, "Receiver");
            }
        }
    }
    void viewFinancialRequestStatus(){
        // list all "production" financial request details
        if (!checkLogin(name)){
            cout << name << " has not logged in yet." << endl;
            return;
        }
        cout << endl << "//Production manager " << name
            << " views financial requests status" << endl;
        if (financialRequestList[0] == NULL){
            cout << "No request in the list yet!" << endl;
            return;
        }
        for (int i = 0; i < 10; i++){
            if (financialRequestList[i] != NULL){
                if (financialRequestList[i]->getDepartment() == "Production"){
                    financialRequestList[i]->view();
                }
            }
            else return;
        }
    }
    void createProductionTask(string date, string depart, string pref,
                 string det, string to){
        subteam_task * new_production_task = new subteam_task(date, depart, pref, det, to);
        add_subteam_task_list(subteam_task_list, new_production_task);
        record->add_employee_record(pref, "Sender"); // add record to profile
        for (int i = 0; i < login_size; i++){
            // add record to task receivers
            if (employee_list[i]->getPosition() == "Production Subteam"){
                employee_list[i]->add_employee_record(pref, "Receiver");
            }
        }
    }

    void viewProductionTaskPlan(){}
    //need filling
    void approveProductionTaskPlan(long budget){
        // add feedback to plan

    }
    //need filling
};

class pt : public employee{
    //production team
public:
    pt(string n, string p, string ID){
        name = n;
        position = p;
        id = ID;
    }
    void view_subteam_task(){
        if (!checkLogin(name)){
            cout << name << " has not logged in yet." << endl;
            return;
        }
        cout << endl << "//Production subteam member " << name
            << " views subteam tasks" << endl;
        if (financialRequestList[0] == NULL){
            cout << "No request in the list yet!" << endl;
            return;
        }
        for (int i = 0; i < subteam_task_number; i++){
            if (subteam_task_list[i] != NULL){
                if (subteam_task_list[i]->get_send_to() == name){
                    subteam_task_list[i]->view();
                }
            }
            else return;
        }
    }
    void create_production_plan(string date, string depart, string pref,
                 string det, long budget){
        // new a production team task and add it to global list
        if (!checkLogin(name)){
            cout << name << " has not logged in yet." << endl;
            return;
        }
        subteam_task_plan * new_production_task_plan = new subteam_task_plan(this->getName(), date, depart, pref, det, budget);
        add_subteam_task_plan_list(subteam_task_plan_list, new_production_task_plan);
    }
    void view_subteam_task_plan(){
        if (!checkLogin(name)){
            cout << name << " has not logged in yet." << endl;
            return;
        }
        cout << endl << "//Production subteam member " << name
            << " views subteam tasks" << endl;
        if (subteam_task_plan_list[0] == NULL){
            cout << "No plan in the list yet!" << endl;
            return;
        }
        for (int i = 0; i < subteam_task_plan_number; i++){
            if (subteam_task_plan_list[i] != NULL){
                if (subteam_task_plan_list[i]->get_creater_name() == name){
                    subteam_task_plan_list[i]->view();
                }
            }
            else return;
        }
    }
};

class sm : public employee{
    //service manager
public:
    sm();
    sm(string Name, string Id, string Position){
        name = Name;
        id = Id;
        position = Position;
    }
    void createFinancialRequest(string date, string depart,
                           string projref, long amount, string rsn){
        //new a f-request and add it to global list.
        if (!checkLogin(name)){
            cout << name << " has not logged in yet." << endl;
            return;
        }
        freq *newFReqPointer = new freq(date, depart, projref, amount, rsn);
        addFinancialRequest(financialRequestList, newFReqPointer);
        record->add_employee_record(projref, "Sender"); // add record to profile
        for (int i = 0; i < login_size; i++){
            // add record to task receivers
            if (employee_list[i]->getPosition() == "Financial Manager"){
                employee_list[i]->add_employee_record(projref, "Receiver");
            }
        }
    }
    void viewFinancialRequestStatus(){
        // list all "service" financial request details
        if (!checkLogin(name)){
            cout << name << " has not logged in yet." << endl;
            return;
        }
        cout << endl << "//Service manager " << name
            << " views financial requests status" << endl;
        if (financialRequestList[0] == NULL){
            cout << "No request in the list yet!" << endl;
            return;
        }
        for (int i = 0; i < 10; i++){
            if (financialRequestList[i] != NULL){
                if (financialRequestList[i]->getDepartment() == "Service"){
                    financialRequestList[i]->view();
                }
            }
            else return;
        }
    }
    createServiceTask();
    //need filling
    viewServiceTaskPlan();
    //need filling
    approveServiceTaskPlan();
    //need filling
};

#endif
