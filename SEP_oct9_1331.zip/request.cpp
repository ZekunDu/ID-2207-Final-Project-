#include "request.h"

using namespace std;

freq *financialRequestList[request_size];

void addFinancialRequest(freq **fr, freq *newFR){
    for (int i = 0; i < request_size; i++){
        if (fr[i] == NULL){
            fr[i] = newFR;
            return;
        }
    }
    cout << "Financial Task is full!" << endl;
    return;
}

freq *getFinancialRequest(string projref){
    for (int i = 0; i < request_size; i++){
        if (financialRequestList[i] == NULL){
            cout << "Not Exist" << endl;
            return NULL;
        }
        if (financialRequestList[i]->getRef() == projref)
            return financialRequestList[i];
    }
    cout << "Not Exist" << endl;
    return NULL;
}

ftask *financialTaskList[request_size];

void addFinancialTask(ftask **ft, ftask *newFT){
    for (int i = 0; i < 10; i++){
        if (ft[i] == NULL){
            ft[i] = newFT;
            return;
        }
    }
    cout << "Financial Task is full!" << endl;
    return;
}
