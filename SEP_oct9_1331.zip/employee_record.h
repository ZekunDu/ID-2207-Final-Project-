#ifndef EMPLOYEE_RECORD_H
#define EMPLOYEE_RECORD_H
#include <string>

class employee_record{
    string project_reference[10];
    string roll[10];
public:
    employee_record(){}
    employee_recoed(string proj_ref, string rol){
        project_reference[0] = proj_ref;
        roll[0] = rol;
    }
    void add_employee_record(string proj_ref, string rol){
        int i = 0;
        while (project_reference[i] != "")
            i++;
        if (i > 9) {
            cout << "Employee_record full!" << endl;
            return;
        }
        project_reference[i] = proj_ref;
        roll[i] = rol;
    }
    void show_employee_record(){
        for (int i = 0; i < 10; i++){
            if (project_reference[i] == "")
                return;
            cout << "Project reference: " << project_reference[i]
             << "; Roll: " << roll[i] <<endl;
        }
    }
};

#endif // EMPLOYEE_RECORD_H
