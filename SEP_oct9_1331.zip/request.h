#ifndef REQUEST_H
#define REQUEST_H
#include <string>
#include <iostream>
#define request_size 10
using namespace std;

class freq{
private:
    string reqDate;
    string department;
    string projReference;
    long reqAmount;
    string reason;
    string status = "unsolved";
    string feedback = "";
public:
    freq(){}
    freq(string date, string depart, string projref, long amount, string rsn){
        reqDate = date;
        department = depart;
        projReference = projref;
        reqAmount = amount;
        reason = rsn;
    }
    void view(){
        cout << "\n>>Reqest Date: " << reqDate << endl;
        cout << ">>Request Department: " << department << endl;
        cout << ">>Project Reference: " << projReference << endl;
        cout << ">>Requested Amount: " << reqAmount << "kr" << endl;
        cout << ">>Reason: " << reason << endl;
        cout << ">>Status: " << status << endl;
        cout << ">>Feedback From Financial Manager: " << feedback << endl;
    }
    void changeDate(string date){
        reqDate = date;
    }
    void changeDepartment(string dep){
        department = dep;
    }
    void changeReference(string refe){
        projReference = refe;
    }
    string getRef(){
        return projReference;
    }
    string getDepartment(){
        return department;
    }
    string getDate(){
        return reqDate;
    }
    long getAmount(){
        return reqAmount;
    }
    string getReason(){
        return reason;
    }
    void changeAmount(long am){
        reqAmount = am;
    }
    void addReason(string rsn){
        reason += "\n";
        reason += rsn;
    }
    void changeStatus(){
        status = "Solved";
    }
    void addFeedback(string fb){
        feedback += " ";
        feedback += fb;
    }
};

extern freq *financialRequestList[request_size];

void addFinancialRequest(freq **fr, freq *newFR);

class ftask{
private:
    string reqDate;
    string department;
    string projReference;
    long reqAmount;
    string reason;
    string comments;
public:
    ftask(){}
    ftask(string date, string depart, string projref, long amount, string rsn){
        reqDate = date;
        department = depart;
        projReference = projref;
        reqAmount = amount;
        reason = rsn;
    }
    void view(){
        cout << "\n>>Reqest Date: " << reqDate << endl;
        cout << ">>Request Department: " << department << endl;
        cout << ">>Project Reference: " << projReference << endl;
        cout << ">>Requested Amount: " << reqAmount << "kr" << endl;
        cout << ">>Reason: " << reason << endl;
        cout << ">>Comments From Financial Manager: " << comments << endl;
    }
    void addComments(string cmt){
        comments += cmt;
    }
};

extern ftask *financialTaskList[request_size];

void addFinancialTask(ftask **ft, ftask *newFT);

freq *getFinancialRequest(string projref);

#endif // REQUEST_H
